/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lambertth
 */
public class FixedPoint
{
   protected int intVal;
   private int qVal;
   
   public FixedPoint(double x, int q)
   {
      intVal = (int)(x * Math.pow(2, q));
      qVal = q;
   }
   public FixedPoint(FixedPoint inpoint)
   {
       intVal = inpoint.intVal;
       qVal = inpoint.qVal;
   }
   public FixedPoint(int x, int y)
   {
       intVal = x;
       qVal = y;
   }
   public double toDouble()
   {
       double temp = (intVal / Math.pow(2, qVal));
       return temp;
   }
   
   private FixedPoint toqVal(int newq)
   {
       int move = qVal - newq;
       if(move > 0)
       {
           
           //increasing q
           /*
           double temp = intVal / Math.pow(2, qVal);
           int temp1 = intVal; 
           temp1 = (int)(temp * Math.pow(2, newq));
           */
           int newint = intVal >> move;
           return new FixedPoint(newint ,newq);
       }
       else
       {
           //decreasing q
           /*
           double temp = intVal / Math.pow(2, qVal);
           int temp1 = intVal;
           temp1 = (int) (temp * Math.pow(2, newq));
           */
           move = move * -1;
           int newint = intVal << move;
           return new FixedPoint(newint, newq);
       }
   }
   
   @Override
   public String toString()
   {
       return String.format( "%d,%d: %.6f", intVal, qVal, toDouble() );
   }
   
   @Override
   public boolean equals(Object obj)
   {
       if( obj instanceof FixedPoint)
       {
           FixedPoint temp = ((FixedPoint) obj);
           FixedPoint temp1 = this;
           
           
           FixedPoint test1 = temp.toqVal(qVal);
           FixedPoint test2 = temp1.toqVal(temp.qVal);
           
           if(test1.intVal == temp1.intVal)
           {
               if(test2.intVal == temp.intVal)
               {
                   return true;
               }
           }
       }
       return false;
   }
   
   public FixedPoint plus(FixedPoint p, int resultQ)
   {
       FixedPoint temp = new FixedPoint(p);
       FixedPoint temp1 = new FixedPoint(this);
       
       temp = temp.toqVal(resultQ);
       temp1 = temp1.toqVal(resultQ);
       
       int temp2 = temp.intVal + temp1.intVal;
       
       FixedPoint yes = new FixedPoint(temp2, resultQ);
       
       return yes;
   }
   public boolean lessThan (FixedPoint p)
   {
       FixedPoint temp = new FixedPoint(p);
       FixedPoint temp1 = new FixedPoint(this);
       if(temp1.qVal > temp.qVal)
       {
           temp1 = temp1.toqVal(temp.qVal);
       }
       else
       {
           temp = temp.toqVal(temp1.qVal);
       }
       if(temp1.intVal < temp.intVal)
       {
           return true;
       }
        return false;
   }
}